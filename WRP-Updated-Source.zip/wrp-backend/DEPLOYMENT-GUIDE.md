# WRP: Android Rename + Admin Web/Backup Server Kit

## Included deliverables

- `WRP_Rebranded.apk`: the uploaded **Relay.apk** with public launcher label and its named app string changed to **WRP**, re-signed with a NEW development signing certificate. The original APK functionality has not intentionally been removed. The APK has **not** been installed on a device or tested. This rename-only APK **does not yet enforce license access**.
- `server/`: standalone FastAPI admin dashboard, key lifecycle, server-side checks, primary + standby SQLite snapshots, HTTPS deployment examples.
- `android-integration/`: Kotlin source code for a launcher license gate and fail-closed primary/backup API check. Must be merged into the original **Android Studio source project** and built/re-signed to truly protect app entry, background services, and automation actions.
- `signing/`: NEW signing key for development builds. Keep PRIVATE; never commit the key to public GitHub repositories.

## Why APK rename and license integration are separate

An Android APK is compiled output; reliable addition of an app-wide license gate requires its project source (particularly `MainActivity` and `AutomationService`). These sources are not included in the uploaded APK. Modifying the launcher alone, without securing the service entry points, would provide a false impression of access control. Therefore the renamed build **is not claimed to have active license enforcement**.

The uploaded **All Models1.0.apk** was NOT used as the base because the latest uploaded **Relay.apk** has a different application ID and implementation. The rebrand preserves `com.local.linnreplica` internally to avoid breaking Shizuku service permissions and Android component authorities. App label is WRP.

## Set up admin server

1. Provision two Linux/VPS hosts or a primary host (standby is optional). Register HTTPS DNS hostnames such as `api.example.com` and `backup.example.com`.
2. In `server/`, copy `.env.example` to `.env`; set strong unique `WRP_SERVER_SECRET` (32+ characters), `WRP_ADMIN_PASSWORD` (12+), `WRP_BACKUP_TOKEN` (24+), `WRP_DOMAIN`, and `WRP_REPLICATION_URL` (blank without standby).
3. For backup host, use `.env.standby.example` as `.env`, set `WRP_MODE=standby`, same `WRP_SERVER_SECRET` and `WRP_BACKUP_TOKEN`, plus its own `WRP_DOMAIN`.
4. Run `docker compose up -d --build` on EACH host. Allow TCP 80/443 through firewall. Verify DNS resolves and Caddy obtains HTTPS certificates.
5. Open `https://api.example.com/admin`, sign in with your admin password, create a key, configure validity and number of devices.
6. Test `https://api.example.com/healthz` and backup `/healthz`. The primary will snapshot its SQLite DB every 5 minutes and push a database snapshot over HTTPS to standby (standby is read-only).
7. Backup recovery limitation: updates (revokes/activations) may take up to 5 minutes to replicate; new device binding is NOT allowed on standby. Use a shorter interval or synchronous change replication in a hardened production deployment.

### Sample client request

```bash
curl -sS https://api.example.com/v1/license/check \
  -H 'Content-Type: application/json' \
  -d '{"license_key":"WRP-REPLACE_WITH_REAL_KEY","device_id":"stable-random-device-uuid"}'
```

Response: `{ "allowed": true, "reason":"valid", "expires_at": ... , "mode":"primary" }` or `{ "allowed": false, "reason":"invalid_key" }`.

## Integrate license requirement into app source

1. Add `WRPLicenseClient.kt` and `WRPLicenseGateActivity.kt` to package `com.local.linnreplica`, and replace `https://api.example.com` / `https://backup.example.com` with real HTTPS domains.
2. Add new `WRPLicenseGateActivity` as the only launcher activity. Remove launcher intent-filter from `MainActivity` and set `android:exported=false` where possible.
3. Also gate `AutomationService` and other exported/background entry points with server-validated license status. Never assume that just hiding UI protects other components.
4. Change `android:label` and `app_name` to `WRP` in source resources. Keep application ID unless planning a proper migration.
5. Store licenses using Android Keystore/Encrypted storage for a production release. Use a production signing key you can safeguard. HTTPS is mandatory.
6. The demo logic fails closed when neither server confirms a license. A standby validates existing registered devices; new devices require primary. No network = no access. Add bounded signed offline grace only if necessary and deliberately approved.

## IMPORTANT: installation and signing

- The new APK is signed with a **different certificate**. It cannot normally update an installed `com.local.linnreplica` signed by the original developer key. You may need to uninstall first; doing so may delete app data. Backup data safely first.
- Keep the signing key/password securely stored. Possession of the private signing key enables publishing updates impersonating this development build.
- This package has not been tested on an actual phone, including Accessibility/Shizuku integrations. Verify function on a spare/testing device before deploying to others.
- License management is an app access-control mechanism, not a replacement for Android/Google Play signing integrity or a defense against an attacker repackaging their own version.
- Do NOT upload APK signing secrets, server `.env`, or production license keys to a public GitHub repository.
