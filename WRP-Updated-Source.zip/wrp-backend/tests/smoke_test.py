"""Run: cd server && python tests/smoke_test.py"""
import os
import re
import sys
import tempfile

os.environ.update({
    "WRP_DATA_DIR": tempfile.mkdtemp(prefix="wrp-smoke-"),
    "WRP_MODE": "primary",
    "WRP_SERVER_SECRET": "test-secret-only-never-use-in-production-123456789",
    "WRP_ADMIN_PASSWORD": "test-password-only-123456789",
    "WRP_SECURE_COOKIE": "0",
    "WRP_AUTO_BACKUP": "0",
})
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from fastapi.testclient import TestClient
from app import app

client = TestClient(app)
assert client.get('/healthz').json()['ok']
assert client.post('/admin/login', data={'password': 'wrong'}).status_code == 403
login = client.post('/admin/login', data={'password': os.environ['WRP_ADMIN_PASSWORD']})
assert login.status_code == 200
csrf = re.search(r'name="csrf_token" value="([0-9a-f]+)"', login.text).group(1)
issued = client.post('/admin/create', data={'csrf_token': csrf, 'note': 'test', 'max_devices': 1, 'days': 10})
assert issued.status_code == 200
key = re.search(r'WRP-[A-Za-z0-9_-]+', issued.text).group()
payload = {'license_key': key, 'device_id': 'sample-test-device-12345'}
assert client.post('/v1/license/check', json=payload).json()['allowed']
assert client.post('/v1/license/check', json={**payload, 'device_id': 'different-test-device-12345'}).json()['reason'] == 'device_limit'
assert client.post('/admin/backup', data={'csrf_token': csrf}).status_code == 200
assert client.post('/admin/license/1/toggle', data={'csrf_token': csrf}).status_code == 200
assert client.post('/v1/license/check', json=payload).json()['reason'] == 'disabled'
print('WRP smoke test PASS')
