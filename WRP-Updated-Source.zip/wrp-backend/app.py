"""WRP license API, owner-only web administration, and SQLite standby replication.

Deployment: HTTPS reverse proxy (see Caddyfile), one Uvicorn worker.
License keys are stored as HMAC hashes; raw keys are shown only once.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import html
import json
import os
import secrets
import shutil
import sqlite3
import tempfile
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from urllib.request import Request, urlopen
from typing import Optional

from fastapi import FastAPI, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse, Response
from pydantic import BaseModel, Field

DATA_DIR = Path(os.getenv("WRP_DATA_DIR", "/data"))
DATA_DIR.mkdir(parents=True, exist_ok=True)
DB = DATA_DIR / "licenses.sqlite3"
BACKUP_DIR = DATA_DIR / "backups"
BACKUP_DIR.mkdir(exist_ok=True)
MODE = os.getenv("WRP_MODE", "primary").lower()
if MODE not in {"primary", "standby"}:
    raise RuntimeError("WRP_MODE must be primary or standby")
ADMIN_PASSWORD = os.getenv("WRP_ADMIN_PASSWORD", "")
SERVER_SECRET = os.getenv("WRP_SERVER_SECRET", "")
BACKUP_TOKEN = os.getenv("WRP_BACKUP_TOKEN", "")
REPLICATION_URL = os.getenv("WRP_REPLICATION_URL", "")
SECURE_COOKIE = os.getenv("WRP_SECURE_COOKIE", "1") == "1"
def strong_enough(value: str, minimum: int) -> bool:
    return len(value) >= minimum and not any(word in value.upper() for word in ('REPLACE', 'CHANGE_ME', 'THE_SAME', 'NOT_USED', 'EXAMPLE'))

if not strong_enough(SERVER_SECRET, 32) or not strong_enough(ADMIN_PASSWORD, 12):
    raise RuntimeError("Set real WRP_SERVER_SECRET (32+ chars) and WRP_ADMIN_PASSWORD (12+ chars); placeholders are not accepted")
if REPLICATION_URL and not REPLICATION_URL.startswith("https://"):
    raise RuntimeError("WRP_REPLICATION_URL must use HTTPS")
if (MODE == "standby" or REPLICATION_URL) and not strong_enough(BACKUP_TOKEN, 24):
    raise RuntimeError("Set WRP_BACKUP_TOKEN (24+ characters) on standby")

app = FastAPI(title="WRP Access Control", docs_url=None, redoc_url=None, openapi_url=None)

def connect() -> sqlite3.Connection:
    db = sqlite3.connect(DB, timeout=20)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA busy_timeout=20000")
    db.execute("PRAGMA journal_mode=WAL")
    db.execute("PRAGMA foreign_keys=ON")
    return db

def init_db():
    if MODE == "standby" and not DB.exists():
        # Standby starts empty; primary replication fills the DB.
        pass
    with connect() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS licenses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            key_hash TEXT UNIQUE NOT NULL,
            key_hint TEXT NOT NULL,
            note TEXT NOT NULL DEFAULT '',
            max_devices INTEGER NOT NULL,
            expires_at INTEGER NOT NULL,
            active INTEGER NOT NULL DEFAULT 1,
            created_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS devices (
            license_id INTEGER NOT NULL,
            device_hash TEXT NOT NULL,
            first_seen INTEGER NOT NULL,
            last_seen INTEGER NOT NULL,
            PRIMARY KEY (license_id, device_hash),
            FOREIGN KEY (license_id) REFERENCES licenses(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS audit (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            occurred_at INTEGER NOT NULL,
            action TEXT NOT NULL,
            license_id INTEGER,
            detail TEXT NOT NULL DEFAULT ''
        );
        """)

init_db()

class RateGate:
    def __init__(self):
        self.entries = {}
        self.lock = threading.Lock()
    def allow(self, token: str, limit: int, window: int = 60) -> bool:
        now = time.monotonic()
        with self.lock:
            values = [t for t in self.entries.get(token, []) if now - t < window]
            if len(values) >= limit:
                self.entries[token] = values
                return False
            values.append(now)
            self.entries[token] = values
            if len(self.entries) > 20000:
                self.entries = {k: v for k, v in self.entries.items() if v[-1] > now - window}
            return True

ratelimiter = RateGate()

def digest(label: str, value: str) -> str:
    return hmac.new(SERVER_SECRET.encode(), (label + ":" + value).encode(), hashlib.sha256).hexdigest()

def now_s() -> int:
    return int(time.time())

class CheckRequest(BaseModel):
    license_key: str = Field(min_length=12, max_length=200)
    device_id: str = Field(min_length=12, max_length=150)

@app.get("/healthz")
def health():
    return {"ok": True, "mode": MODE, "backupConfigured": bool(REPLICATION_URL)}

@app.post("/v1/license/check")
def check_license(payload: CheckRequest, request: Request):
    ip = request.client.host if request.client else "unknown"
    if not ratelimiter.allow("check:" + ip, 120):
        raise HTTPException(status_code=429, detail="Too many requests")
    key_hash = digest("license", payload.license_key.strip())
    device_hash = digest("device", payload.device_id.strip())
    t = now_s()
    with connect() as db:
        db.execute("BEGIN IMMEDIATE" if MODE == "primary" else "BEGIN")
        item = db.execute("SELECT * FROM licenses WHERE key_hash=?", (key_hash,)).fetchone()
        if not item:
            return {"allowed": False, "reason": "invalid_key"}
        if not item["active"]:
            return {"allowed": False, "reason": "disabled"}
        if item["expires_at"] <= t:
            return {"allowed": False, "reason": "expired"}
        prior = db.execute("SELECT 1 FROM devices WHERE license_id=? AND device_hash=?", (item["id"], device_hash)).fetchone()
        if not prior:
            if MODE == "standby":
                return {"allowed": False, "reason": "new_device_requires_primary"}
            bound = db.execute("SELECT COUNT(*) FROM devices WHERE license_id=?", (item["id"],)).fetchone()[0]
            if bound >= item["max_devices"]:
                return {"allowed": False, "reason": "device_limit"}
            db.execute("INSERT INTO devices VALUES (?,?,?,?)", (item["id"], device_hash, t, t))
        elif MODE == "primary":
            db.execute("UPDATE devices SET last_seen=? WHERE license_id=? AND device_hash=?", (t, item["id"], device_hash))
    return {"allowed": True, "reason": "valid", "expires_at": item["expires_at"], "mode": MODE}

COOKIE_NAME = "wrp_admin_session"

def make_cookie() -> str:
    timestamp = str(now_s())
    nonce = secrets.token_hex(12)
    message = timestamp + ":" + nonce
    proof = digest("session", message)
    return base64.urlsafe_b64encode((message + ":" + proof).encode()).decode()

def valid_session(cookie: str) -> bool:
    try:
        raw = base64.urlsafe_b64decode(cookie.encode()).decode()
        t, nonce, proof = raw.split(":")
        if not (0 <= now_s() - int(t) < 8 * 3600):
            return False
        return hmac.compare_digest(proof, digest("session", t + ":" + nonce))
    except Exception:
        return False

def auth(request: Request) -> str:
    cookie = request.cookies.get(COOKIE_NAME, "")
    if not valid_session(cookie):
        raise HTTPException(status_code=401, detail="Admin login required")
    return cookie

def csrf(cookie: str) -> str:
    return digest("csrf", cookie)

def require_admin_post(request: Request, token: str):
    cookie = auth(request)
    if not hmac.compare_digest(token, csrf(cookie)):
        raise HTTPException(status_code=403, detail="Invalid CSRF token")
    if MODE != "primary":
        raise HTTPException(status_code=403, detail="Standby is read-only")

def page(title: str, body: str) -> HTMLResponse:
    css = """
    :root {font-family:system-ui,-apple-system,Arial; color-scheme:dark}
    body {background:#0a1325;color:#e9efff;max-width:1050px;margin:38px auto;padding:0 18px}
    h1,h2{letter-spacing:-.03em}h1{color:#86b8ff} .sub{color:#a4b1c9}
    section{background:#131f33;border:1px solid #334158;border-radius:18px;padding:22px;margin:20px 0}
    label{display:block;margin:12px 0 4px}input,button{font:inherit;padding:12px;border-radius:10px}
    input{background:#0b1526;border:1px solid #475771;color:#fff;max-width:100%;box-sizing:border-box}
    button{background:#458fff;color:#08172b;border:0;font-weight:700;cursor:pointer}
    button.danger{background:#ef9aa5;color:#431d23} table{border-collapse:collapse;width:100%;font-size:14px}
    td,th{border-bottom:1px solid #334158;padding:12px 9px;text-align:left;vertical-align:top}
    form.inline{display:inline-block;margin:2px} .hint{color:#b1bfd2;font-size:14px}
    .key{padding:15px;background:#101f37;color:#9ae6d0;overflow-wrap:anywhere;font-family:monospace}
    a{color:#89bdff} .scroll{overflow-x:auto} .status{color:#80d8a7}
    """
    return HTMLResponse(f'<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{html.escape(title)}</title><style>{css}</style></head><body>{body}</body></html>')

@app.get("/admin", response_class=HTMLResponse)
def admin_home(request: Request):
    cookie = request.cookies.get(COOKIE_NAME, "")
    if not valid_session(cookie):
        return page("WRP Admin Sign In", """<h1>WRP Control Center</h1><p class="sub">Administrator sign in</p><section><form method="post" action="/admin/login"><label>Admin password</label><input type="password" name="password" required autocomplete="current-password" style="width:320px"><p><button type="submit">Sign in</button></p></form></section>""")
    with connect() as db:
        licenses = db.execute("SELECT l.*, (SELECT COUNT(*) FROM devices d WHERE d.license_id=l.id) AS device_count FROM licenses l ORDER BY id DESC LIMIT 200").fetchall()
        logs = db.execute("SELECT * FROM audit ORDER BY id DESC LIMIT 15").fetchall()
    token = csrf(cookie)
    top = '<h1>WRP Control Center</h1><p class="sub">License management · Device access · Backup status</p>'
    if MODE == "standby":
        top += '<p>Read-only standby</p>'
    else:
        top += f'''<section><h2>Create Access Key</h2><form action="/admin/create" method="post">
          <input type="hidden" name="csrf_token" value="{token}">
          <label>Customer / note</label><input name="note" maxlength="120" placeholder="Customer A" style="width:350px">
          <label>Allowed devices (1–100)</label><input name="max_devices" type="number" min="1" max="100" value="1">
          <label>Validity (days, 1–3650)</label><input name="days" type="number" min="1" max="3650" value="30">
          <p><button type="submit">Generate key</button></p></form></section>'''
    rows = []
    for k in licenses:
        is_active = k["active"] and k["expires_at"] > now_s()
        exp = datetime.fromtimestamp(k["expires_at"], tz=timezone.utc).strftime("%Y-%m-%d")
        controls = ''
        if MODE == 'primary':
            controls = (f'<form class="inline" method="post" action="/admin/license/{k["id"]}/toggle">'
                        f'<input type="hidden" name="csrf_token" value="{token}">'
                        f'<button type="submit" class="danger">{"Disable" if k["active"] else "Enable"}</button></form>'
                        f'<form class="inline" method="post" action="/admin/license/{k["id"]}/reset">'
                        f'<input type="hidden" name="csrf_token" value="{token}"><button type="submit">Reset devices</button></form>')
        rows.append(f'<tr><td>{k["id"]}</td><td>{html.escape(k["note"])}</td><td>{html.escape(k["key_hint"])}</td><td>{k["device_count"]}/{k["max_devices"]}</td><td>{exp}</td><td>{"Active" if is_active else "Disabled/Expired"}</td><td>{controls}</td></tr>')
    top += '<section><h2>Issued keys</h2><div class="scroll"><table><tr><th>ID</th><th>Note</th><th>Key hint</th><th>Devices</th><th>Expires UTC</th><th>Status</th><th>Actions</th></tr>'+''.join(rows)+'</table></div><p class="hint">Only hashes are stored; an issued key cannot be recovered. Create a replacement if lost.</p></section>'
    logrows = ''.join(f'<tr><td>{datetime.fromtimestamp(x["occurred_at"],timezone.utc).strftime("%m-%d %H:%M")}</td><td>{html.escape(x["action"])}</td><td>{x["license_id"] or "-"}</td></tr>' for x in logs)
    top += f'<section><h2>Audit log (latest 15)</h2><table><tr><th>UTC</th><th>Action</th><th>License</th></tr>{logrows}</table></section>'
    if MODE == 'primary':
        top += f'<section><h2>Backup</h2><p>Snapshots are saved locally and can be replicated to a configured standby HTTPS endpoint.</p><form method="post" action="/admin/backup"><input type="hidden" name="csrf_token" value="{token}"><button type="submit">Backup now</button></form><p class="hint">Standby replication: {"configured" if REPLICATION_URL else "not configured"}</p></section>'
    top += f'<form method="post" action="/admin/logout"><input type="hidden" name="csrf_token" value="{token}"><button type="submit">Sign out</button></form>'
    return page('WRP Control Center', top)

@app.post('/admin/login')
def login(request: Request, password: str = Form(...)):
    ip = request.client.host if request.client else 'unknown'
    if not ratelimiter.allow('login:' + ip, 8, 300):
        raise HTTPException(status_code=429, detail='Too many sign-in attempts')
    if not hmac.compare_digest(password, ADMIN_PASSWORD):
        raise HTTPException(status_code=403, detail='Invalid password')
    response = RedirectResponse('/admin', status_code=303)
    response.set_cookie(COOKIE_NAME, make_cookie(), httponly=True, secure=SECURE_COOKIE, samesite='strict', max_age=8*3600)
    return response

@app.post('/admin/logout')
def logout(request: Request, csrf_token: str = Form(...)):
    cookie = auth(request)
    if not hmac.compare_digest(csrf_token, csrf(cookie)):
        raise HTTPException(status_code=403, detail="Invalid CSRF token")
    response = RedirectResponse('/admin', status_code=303)
    response.delete_cookie(COOKIE_NAME)
    return response

@app.post('/admin/create')
def create(request: Request, csrf_token: str=Form(...), note: str=Form(''), max_devices: int=Form(1), days: int=Form(30)):
    require_admin_post(request, csrf_token)
    if not (1 <= max_devices <= 100 and 1 <= days <= 3650 and len(note) <= 120):
        raise HTTPException(status_code=400, detail='Invalid fields')
    key = 'WRP-' + secrets.token_urlsafe(30)
    t = now_s()
    with connect() as db:
        cur = db.execute('INSERT INTO licenses (key_hash,key_hint,note,max_devices,expires_at,active,created_at) VALUES (?,?,?,?,?,1,?)',
                         (digest('license', key), key[:9]+'…',note,max_devices,t+days*86400,t))
        db.execute('INSERT INTO audit (occurred_at,action,license_id,detail) VALUES (?,?,?,?)', (t,'created',cur.lastrowid, f'days={days};max={max_devices}'))
    return page('Access key created', f'<h1>WRP key created</h1><p>Save this key now. It will never be displayed again.</p><section><p class="key">{html.escape(key)}</p><p class="hint">Expires in {days} days. Maximum {max_devices} device(s).</p></section><p><a href="/admin">← Return to dashboard</a></p>')

@app.post('/admin/license/{lid}/toggle')
def toggle(lid: int, request: Request, csrf_token: str=Form(...)):
    require_admin_post(request, csrf_token)
    with connect() as db:
        item = db.execute('SELECT active FROM licenses WHERE id=?',(lid,)).fetchone()
        if not item: raise HTTPException(status_code=404)
        db.execute('UPDATE licenses SET active=? WHERE id=?',(0 if item['active'] else 1,lid))
        db.execute('INSERT INTO audit (occurred_at,action,license_id) VALUES (?,?,?)',(now_s(),'disabled' if item['active'] else 'enabled',lid))
    return RedirectResponse('/admin', status_code=303)

@app.post('/admin/license/{lid}/reset')
def reset(lid: int, request: Request, csrf_token: str=Form(...)):
    require_admin_post(request, csrf_token)
    with connect() as db:
        db.execute('DELETE FROM devices WHERE license_id=?',(lid,))
        db.execute('INSERT INTO audit (occurred_at,action,license_id) VALUES (?,?,?)',(now_s(),'devices_reset',lid))
    return RedirectResponse('/admin', status_code=303)

def backup_snapshot() -> Path:
    out = BACKUP_DIR / f'wrp-{now_s()}-{secrets.token_hex(3)}.sqlite3'
    with connect() as source, sqlite3.connect(out) as dest:
        source.backup(dest)
    out.chmod(0o600)
    snapshots = sorted(BACKUP_DIR.glob('wrp-*.sqlite3'))
    for old in snapshots[:-50]:
        old.unlink(missing_ok=True)
    if REPLICATION_URL:
        if not BACKUP_TOKEN:
            raise RuntimeError('Missing WRP_BACKUP_TOKEN')
        body = out.read_bytes()
        req = Request(REPLICATION_URL.rstrip('/') + '/internal/replicate', data=body,
                      headers={'Authorization': 'Bearer '+BACKUP_TOKEN,'Content-Type':'application/octet-stream'}, method='POST')
        with urlopen(req, timeout=20) as resp:
            if resp.status != 200: raise RuntimeError(f'Replication failed: {resp.status}')
    return out

@app.post('/admin/backup')
def backup_now(request: Request, csrf_token: str=Form(...)):
    require_admin_post(request, csrf_token)
    try:
        path = backup_snapshot()
    except Exception as ex:
        raise HTTPException(status_code=502, detail='Local snapshot written; remote replication failed. Check server logs.') from ex
    return page('Backup completed',f'<h1>Local backup completed</h1><p>{html.escape(path.name)}</p><p><a href="/admin">Return to dashboard</a></p>')

@app.post('/internal/replicate')
async def replicate(request: Request):
    if MODE != 'standby': raise HTTPException(status_code=404)
    auth_header = request.headers.get('authorization','')
    if not hmac.compare_digest(auth_header, 'Bearer ' + BACKUP_TOKEN):
        raise HTTPException(status_code=403)
    if int(request.headers.get('content-length', 0)) > 50_000_000:
        raise HTTPException(status_code=413)
    payload = await request.body()
    if len(payload) > 50_000_000 or not payload.startswith(b'SQLite format 3\0'):
        raise HTTPException(status_code=400,detail='Invalid database snapshot')
    fd, fname = tempfile.mkstemp(dir=DATA_DIR, prefix='incoming-', suffix='.db')
    try:
        with os.fdopen(fd,'wb') as f: f.write(payload)
        with sqlite3.connect(fname) as d:
            state = d.execute('PRAGMA integrity_check').fetchone()[0]
            if state != 'ok': raise HTTPException(status_code=400, detail='Corrupt snapshot')
        # Standby connection is per request; atomic file replacement prevents partial files.
        os.chmod(fname,0o600)
        os.replace(fname,DB)
        for suffix in ['-wal','-shm']:
            Path(str(DB)+suffix).unlink(missing_ok=True)
    finally:
        if os.path.exists(fname): os.unlink(fname)
    return {'ok':True,'timestamp':now_s()}

# Periodic snapshot replication from primary; no external scheduler needed.
def periodic_backup():
    while True:
        time.sleep(300)
        try:
            backup_snapshot()
        except Exception as ex:
            print('WRP backup error:',str(ex),flush=True)

if MODE == 'primary' and os.getenv('WRP_AUTO_BACKUP','1') == '1':
    threading.Thread(target=periodic_backup,daemon=True).start()
