'use strict';

const { test } = require('node:test');
const assert = require('node:assert/strict');
const { spawn } = require('node:child_process');
const { once } = require('node:events');
const { mkdtemp, readFile, writeFile, rm } = require('node:fs/promises');
const { tmpdir } = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const net = require('node:net');
const vm = require('node:vm');

test('activation lifecycle enforces administrator authority and durable device binding', async (t) => {
  const directory = await mkdtemp(path.join(tmpdir(), 'wrp-test-'));
  const store = path.join(directory, 'keys.json');
  const token = crypto.randomBytes(32).toString('hex');
  const pepper = crypto.randomBytes(32).toString('hex');
  let child;
  let origin;

  async function stop() {
    if (child && child.exitCode === null) {
      const exited = once(child, 'exit');
      child.kill('SIGTERM');
      await exited;
    }
  }
  t.after(async () => { await stop(); await rm(directory, { recursive: true, force: true }); });

  async function start() {
    const probe = net.createServer();
    probe.listen(0, '127.0.0.1');
    await once(probe, 'listening');
    const port = probe.address().port;
    await new Promise(resolve => probe.close(resolve));
    origin = `http://127.0.0.1:${port}`;
    child = spawn(process.execPath, ['server.js'], {
      cwd: path.resolve(__dirname, '..'),
      env: { ...process.env, PORT: String(port), HOST: '127.0.0.1',
        ADMIN_TOKEN: token, KEY_PEPPER: pepper, STORE_FILE: store },
      stdio: ['ignore', 'pipe', 'pipe']
    });
    // Do not echo child output: runtime credentials must never enter test logs.
    child.stderr.resume();
    await new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error('Server startup timeout')), 5000);
      child.once('error', reject);
      child.once('exit', () => { clearTimeout(timer); reject(new Error('Server exited before ready')); });
      child.stdout.once('data', () => { clearTimeout(timer); resolve(); });
    });
    child.stdout.resume();
  }

  async function api(route, { method = 'GET', body, admin = false } = {}) {
    const response = await fetch(origin + route, {
      method,
      headers: { 'Content-Type': 'application/json', ...(admin ? { Authorization: `Bearer ${token}` } : {}) },
      body: body === undefined ? undefined : JSON.stringify(body)
    });
    return { status: response.status, data: await response.json(), headers: response.headers };
  }
  const issue = (days = 30) => api('/api/admin/keys', { method: 'POST', admin: true, body: { days } });
  const activate = (key, deviceId = 'installation-one') => api('/api/activate', {
    method: 'POST', body: { key, deviceId }
  });

  await start();
  await t.test('health and admin page have safe response headers', async () => {
    const health = await api('/health');
    assert.equal(health.status, 200);
    assert.equal(health.headers.get('cache-control'), 'no-store');
    const page = await fetch(origin + '/admin');
    assert.equal(page.status, 200);
    assert.equal(page.headers.get('x-frame-options'), 'DENY');
    assert.ok(page.headers.get('content-security-policy').includes("connect-src 'self'"));
    assert.ok(!(await page.text()).includes(token));
  });

  await t.test('locking the console discards an in-flight issued key response', async () => {
    const html = await (await fetch(origin + '/admin')).text();
    const script = html.match(/<script>([\s\S]*?)<\/script>/)[1];
    const elements = Object.fromEntries(['token', 'days', 'issue', 'list', 'lock', 'generated', 'keys', 'message']
      .map(id => [id, { value: '', textContent: '', hidden: true, replaceChildren() {} }]));
    elements.token.value = token;
    elements.days.value = '30';
    let complete;
    vm.runInNewContext(script, {
      document: { getElementById: id => elements[id] },
      fetch: () => new Promise(resolve => { complete = resolve; })
    });
    const issuing = elements.issue.onclick();
    elements.lock.onclick();
    complete({ ok: true, json: async () => ({ ok: true, key: 'test-only-issued-key' }) });
    await issuing;
    assert.equal(elements.token.value, '');
    assert.equal(elements.generated.textContent, '');
    assert.equal(elements.generated.hidden, true);
    assert.equal(elements.message.textContent, 'Console locked.');
  });

  await t.test('admin endpoints deny unauthenticated and incorrect tokens', async () => {
    for (const [route, method] of [
      ['/api/admin/keys', 'GET'], ['/api/admin/keys', 'POST'], ['/api/admin/keys/revoke', 'POST']
    ]) assert.equal((await api(route, { method })).status, 401);
    const response = await fetch(origin + '/api/admin/keys', { headers: { Authorization: 'Bearer wrong' } });
    assert.equal(response.status, 401);
  });

  await t.test('validation rejects malformed bodies, durations and unknown keys', async () => {
    for (const days of [0, 366, 1.5, '30']) assert.equal((await issue(days)).status, 400);
    assert.equal((await activate('bad-key')).status, 400);
    assert.equal((await activate('wrp_' + 'a'.repeat(32), 'short')).status, 400);
    assert.equal((await activate('wrp_' + 'a'.repeat(32))).status, 403);
    for (const body of ['{', 'null', '[]']) {
      const response = await fetch(origin + '/api/activate', { method: 'POST', body });
      assert.equal(response.status, 400);
    }
  });

  let key, id;
  await t.test('issued keys bind to one installation and never appear in listings or storage', async () => {
    const created = await issue();
    assert.equal(created.status, 201);
    key = created.data.key;
    id = created.data.id;
    assert.ok(/^wrp_[A-Za-z0-9_-]{32}$/.test(key));
    const active = await activate(key);
    assert.equal(active.status, 200);
    assert.equal(active.data.expiresAt, created.data.expiresAt);
    assert.equal((await activate(key)).status, 200);
    assert.equal((await activate(key, 'installation-two')).status, 403);
    const listed = await api('/api/admin/keys', { admin: true });
    assert.equal(listed.status, 200);
    assert.equal(listed.data.keys[0].bound, true);
    assert.ok(!JSON.stringify(listed.data).includes(key));
    const stored = await readFile(store, 'utf8');
    assert.ok(!stored.includes(key));
    assert.ok(!stored.includes('installation-one'));
    assert.ok(!stored.includes(token));
    assert.ok(!stored.includes(pepper));
  });

  await t.test('device binding survives restart', async () => {
    await stop(); await start();
    assert.equal((await activate(key)).status, 200);
    assert.equal((await activate(key, 'installation-two')).status, 403);
  });

  await t.test('revocation immediately denies activation and survives restart', async () => {
    const revoked = await api('/api/admin/keys/revoke', { method: 'POST', admin: true, body: { id } });
    assert.equal(revoked.status, 200);
    assert.equal((await activate(key)).status, 403);
    await stop(); await start();
    assert.equal((await activate(key)).status, 403);
  });

  await t.test('expired and malformed expiry records fail closed', async () => {
    const issued = await issue(1);
    assert.equal(issued.status, 201);
    await stop();
    const data = JSON.parse(await readFile(store, 'utf8'));
    const record = data.keys.find(item => item.id === issued.data.id);
    record.expiresAt = new Date(Date.now() - 1000).toISOString();
    await writeFile(store, JSON.stringify(data));
    await start();
    assert.equal((await activate(issued.data.key)).status, 403);
    await stop();
    record.expiresAt = 'invalid';
    await writeFile(store, JSON.stringify(data));
    await start();
    assert.equal((await activate(issued.data.key)).status, 403);
  });

  await t.test('excess activation attempts are rate limited', async () => {
    let status;
    for (let i = 0; i < 61; i++) status = (await activate('bad-key')).status;
    assert.equal(status, 429);
  });
});
