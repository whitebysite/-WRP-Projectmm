package mm.wrp.project;

import org.junit.Test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;

public class ActivationClientTest {
    @Test public void normalizesHttpsOrigins() throws Exception {
        assertEquals("https://wrp.example", ActivationClient.normalizeServer(" https://wrp.example/ "));
        assertEquals("https://wrp.example:8443", ActivationClient.normalizeServer("https://wrp.example:8443//"));
        assertEquals("https://wrp.example", ActivationClient.normalizeServer("HTTPS://wrp.example"));
    }

    @Test public void rejectsUnsafeOrAmbiguousServerAddresses() {
        String[] invalid = {
            "http://wrp.example", "ftp://wrp.example", "wrp.example", "https://",
            "https://user:password@wrp.example", "https://wrp.example/api",
            "https://wrp.example?key=value", "https://wrp.example#fragment",
            "https://wrp.example:0", "https://wrp.example:70000",
            "https://wrp.example\\@other.example"
        };
        for (String server : invalid) {
            assertThrows("Must reject unsafe origin", Exception.class,
                    () -> ActivationClient.normalizeServer(server));
        }
    }
}
