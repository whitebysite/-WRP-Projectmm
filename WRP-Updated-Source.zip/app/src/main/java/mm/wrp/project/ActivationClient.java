package mm.wrp.project;

import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import javax.net.ssl.HttpsURLConnection;

/** Device-only API client. Administrator credentials never belong in the APK. */
final class ActivationClient {
    static String normalizeServer(String value) throws Exception {
        URI uri = new URI(value.trim());
        if (!"https".equalsIgnoreCase(uri.getScheme()) || uri.getHost() == null ||
                uri.getRawUserInfo() != null || uri.getRawQuery() != null ||
                uri.getRawFragment() != null ||
                uri.getPort() == 0 || uri.getPort() > 65535 ||
                (uri.getRawPath() != null && !uri.getRawPath().matches("/*"))) {
            throw new IllegalArgumentException("Enter an HTTPS server origin without a path or credentials.");
        }
        return new URI("https", null, uri.getHost(), uri.getPort(), null, null, null).toASCIIString();
    }

    JSONObject activate(String server, String key, String deviceId) throws Exception {
        String origin = normalizeServer(server);
        HttpsURLConnection connection = (HttpsURLConnection)
                new URI(origin + "/api/activate").toURL().openConnection();
        try {
            // A redirect must never forward the activation key to another origin.
            connection.setInstanceFollowRedirects(false);
            connection.setConnectTimeout(20000);
            connection.setReadTimeout(90000);
            connection.setRequestMethod("POST");
            connection.setDoOutput(true);
            connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            connection.setRequestProperty("Accept", "application/json");
            JSONObject input = new JSONObject().put("key", key).put("deviceId", deviceId);
            try (OutputStream out = connection.getOutputStream()) {
                out.write(input.toString().getBytes(StandardCharsets.UTF_8));
            }
            int status = connection.getResponseCode();
            if (status >= 300 && status < 400) throw new IllegalStateException("Redirect refused");
            InputStream stream = status >= 200 && status < 300 ?
                    connection.getInputStream() : connection.getErrorStream();
            if (stream == null) throw new IllegalStateException("Empty server response");
            JSONObject response;
            try (InputStream in = stream; ByteArrayOutputStream bytes = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[2048];
                int count;
                while ((count = in.read(buffer)) != -1) {
                    bytes.write(buffer, 0, count);
                    if (bytes.size() > 65536) throw new IllegalStateException("Response too large");
                }
                response = new JSONObject(new String(bytes.toByteArray(), StandardCharsets.UTF_8));
            }
            if (status != 200 || !response.optBoolean("ok", false)) {
                throw new IllegalStateException("Activation rejected");
            }
            if (response.optString("expiresAt").isEmpty()) throw new IllegalStateException("Missing expiry");
            return response;
        } finally {
            connection.disconnect();
        }
    }
}
