package mm.wrp.project;

import org.json.JSONObject;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.net.URI;
import javax.net.ssl.HttpsURLConnection;

/** Client for WRP FastAPI primary and read-only standby. */
final class WrpLicenseApi {
    static final class Result {
        final boolean allowed;
        final String reason, endpoint;
        Result(boolean a,String r,String e){allowed=a;reason=r;endpoint=e;}
    }
    static Result check(String primary,String backup,String key,String device) {
        String[] endpoints={primary,backup};
        String reason="network_unavailable";
        for (String url:endpoints){
            if(url==null||url.isEmpty())continue;
            HttpsURLConnection con=null;
            try {
                String origin=ActivationClient.normalizeServer(url);
                con=(HttpsURLConnection)new URI(origin+"/v1/license/check").toURL().openConnection();
                con.setInstanceFollowRedirects(false);
                con.setConnectTimeout(8000);
                con.setReadTimeout(8000);
                con.setRequestMethod("POST");
                con.setDoOutput(true);
                con.setRequestProperty("Content-Type","application/json; charset=UTF-8");
                JSONObject req=new JSONObject().put("license_key",key).put("device_id",device);
                try(OutputStream out=con.getOutputStream()){out.write(req.toString().getBytes(StandardCharsets.UTF_8));}
                if(con.getResponseCode()!=200){reason="server_http_"+con.getResponseCode();continue;}
                byte[] bytes;
                try(InputStream in=con.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){
                    byte[] buf=new byte[1024];int n;while((n=in.read(buf))!=-1){out.write(buf,0,n);if(out.size()>16384)throw new IllegalStateException("Response too large");}bytes=out.toByteArray();
                }
                JSONObject response=new JSONObject(new String(bytes,StandardCharsets.UTF_8));
                boolean allowed=response.optBoolean("allowed",false);
                reason=response.optString("reason","unknown");
                if(!allowed && "new_device_requires_primary".equals(reason))continue;
                return new Result(allowed,reason,origin);
            }catch(Exception e){reason="network_unavailable";}
            finally{if(con!=null)con.disconnect();}
        }
        return new Result(false,reason,"");
    }
}
