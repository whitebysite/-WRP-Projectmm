package mm.wrp.project;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;

/** WRP first-party workspace. No automated account creation or OTP scraping. */
public class MainActivity extends Activity {
    private static final String PREF="wrp_v1_workspace";
    private static final int IMPORT_NUMBERS=21, EXPORT_BACKUP=22, IMPORT_BACKUP=23;
    private static final int BLUE=Color.rgb(29,151,255), SKY=Color.rgb(94,214,255);
    private SharedPreferences prefs;
    private SecureStore keystore;
    private LinearLayout root;
    private boolean unlocked=false, checking=false;
    private long checkedAt=0;
    private String current="home", device;
    private int base=0xff050c19, card=0xff0c1d34, text=Color.WHITE, muted=0xffa6bdd8, border=0xff174675;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs=getSharedPreferences(PREF,MODE_PRIVATE);
        keystore=new SecureStore(this);
        device=prefs.getString("device_uuid","");
        if(device.isEmpty()) { device=UUID.randomUUID().toString();prefs.edit().putString("device_uuid",device).apply(); }
        themeColors();
        if(keystore.get()!=null && !prefs.getString("primary","").isEmpty()) checkLicense(false);
        else showActivation("Enter the admin-issued key to unlock WRP.");
    }
    @Override protected void onResume() {
        super.onResume();
        if(unlocked && !checking && System.currentTimeMillis()-checkedAt>30000)checkLicense(false);
    }
    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private void themeColors(){
        String t=prefs.getString("theme","darkblue");
        if("light".equals(t)){base=0xffeaf2ff;card=Color.WHITE;text=0xff14243f;muted=0xff526a86;border=0xffb6cde9;}
        else if("gold".equals(t)){base=0xff10151d;card=0xff19212d;text=Color.WHITE;muted=0xffbdc7d3;border=0xff6a5637;}
        else {base=0xff050c19;card=0xff0c1d34;text=Color.WHITE;muted=0xffa6bdd8;border=0xff174675;}
    }
    private int accent(){return "gold".equals(prefs.getString("theme","darkblue"))?0xffe5c17a:BLUE;}
    private GradientDrawable shape(int fill,int edge,int r){GradientDrawable d=new GradientDrawable();d.setColor(fill);d.setCornerRadius(dp(r));if(edge!=0)d.setStroke(dp(1),edge);return d;}
    private void startScreen(String title,String subtitle){
        themeColors();
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(base);
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(18),dp(27),dp(18),dp(24));
        scroll.addView(root);setContentView(scroll);
        TextView brand=txt("✈  WRP APP",26,true,accent());root.addView(brand);
        TextView version=txt("PRIVATE WORKSPACE   ·   v1.0",10,true,muted);version.setLetterSpacing(0.15f);root.addView(version);
        gap(15);root.addView(txt(title,22,true,text));root.addView(txt(subtitle,12,false,muted));gap(13);
    }
    private void gap(int d){View v=new View(this);root.addView(v,new LinearLayout.LayoutParams(1,dp(d)));}
    private TextView txt(String value,int size,boolean bold,int color){
        TextView t=new TextView(this);t.setText(value);t.setTextColor(color);t.setTextSize(TypedValue.COMPLEX_UNIT_SP,size);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);t.setPadding(dp(2),dp(5),dp(2),dp(6));return t;
    }
    private LinearLayout panel(){LinearLayout p=new LinearLayout(this);p.setOrientation(LinearLayout.VERTICAL);p.setPadding(dp(15),dp(14),dp(15),dp(15));p.setBackground(shape(card,border,15));LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,-2);pp.bottomMargin=dp(12);root.addView(p,pp);return p;}
    private LinearLayout row(LinearLayout parent){LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.HORIZONTAL);r.setGravity(Gravity.CENTER_VERTICAL);parent.addView(r,new LinearLayout.LayoutParams(-1,-2));return r;}
    private void line(LinearLayout p,String title,String detail){p.addView(txt(title,15,true,text));if(detail!=null&&!detail.isEmpty())p.addView(txt(detail,12,false,muted));}
    private Button action(LinearLayout p,String title,Runnable onClick){
        Button b=new Button(this);b.setText(title);b.setAllCaps(false);b.setTextSize(15);b.setTextColor(Color.WHITE);
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x44ffffff),shape(accent(),0,12),null));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(51));lp.topMargin=dp(9);p.addView(b,lp);b.setOnClickListener(v->onClick.run());return b;
    }
    private Button secondary(LinearLayout p,String title,Runnable onClick){
        Button b=action(p,title,onClick);b.setTextColor(text);b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x33ffffff),shape(card,border,12),null));return b;
    }
    private EditText input(LinearLayout p,String hint,String value,boolean secret){
        EditText f=new EditText(this);f.setSingleLine(true);f.setTextSize(15);f.setTextColor(text);f.setHintTextColor(muted);f.setHint(hint);f.setPadding(dp(13),0,dp(13),0);f.setBackground(shape(base,border,10));
        f.setInputType(secret?(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD):InputType.TYPE_CLASS_TEXT);
        f.setText(value);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(51));lp.bottomMargin=dp(8);p.addView(f,lp);return f;
    }
    private void bottom(){gap(5);LinearLayout nav=panel();LinearLayout rr=row(nav);String[] tabs={"Home","Accounts","Tools","Settings"};String[] pages={"home","accounts","tools","settings"};for(int i=0;i<tabs.length;i++){final String dest=pages[i];TextView t=txt(tabs[i],12,true,current.equals(dest)?accent():muted);t.setGravity(Gravity.CENTER);rr.addView(t,new LinearLayout.LayoutParams(0,dp(45),1));t.setOnClickListener(v->open(dest));}}
    private void open(String page){if(!unlocked){showActivation("Your license must be validated.");return;}current=page;switch(page){case "accounts":accounts();break;case "tools":tools();break;case "settings":settings();break;case "create":create();break;case "gmail":gmail();break;case "logs":logs();break;case "backup":backup();break;default:home();}}
    private void showActivation(String message){unlocked=false;startScreen("Activate WRP","Secure admin-managed access");LinearLayout p=panel();line(p,"ADMIN KEY",message);gap(3);
        p.addView(txt("Primary HTTPS server",12,true,muted));EditText primary=input(p,"https://api.example.com",prefs.getString("primary",""),false);
        p.addView(txt("Backup HTTPS server (optional)",12,true,muted));EditText backup=input(p,"https://backup.example.com",prefs.getString("backup",""),false);
        p.addView(txt("Activation key",12,true,muted));EditText key=input(p,"WRP-...", "",true);
        action(p,"Activate / Verify",()->{
            String first=primary.getText().toString().trim(),second=backup.getText().toString().trim(),value=key.getText().toString().trim();
            try{ActivationClient.normalizeServer(first);if(!second.isEmpty())ActivationClient.normalizeServer(second);}catch(Exception e){toast("Use HTTPS server origins only.");return;}
            if(value.length()<12){toast("Enter the activation key issued by the admin.");return;}
            prefs.edit().putString("primary",first).putString("backup",second).apply();
            try{keystore.put(value);}catch(Exception e){toast("Could not securely store key.");return;}
            checkLicense(true);
        });
        if(keystore.get()!=null)secondary(p,"Retry saved license",()->checkLicense(false));
        p=panel();line(p,"First-party WRP workspace","Your admin token and server secrets never belong inside this APK. This is a separate UI rebuild, not the original Relay bytecode.");
    }
    private void checkLicense(boolean first){
        if(checking)return;String key=keystore.get();if(key==null){showActivation("Enter an activation key.");return;}
        checking=true;startScreen("Checking access","Contacting primary / standby server");panel().addView(txt("Validating your device-bound license…",14,false,muted));
        String primary=prefs.getString("primary",""),backup=prefs.getString("backup","");
        new Thread(()->{
            WrpLicenseApi.Result result=WrpLicenseApi.check(primary,backup,key,device);
            runOnUiThread(()->{checking=false;if(result.allowed){unlocked=true;checkedAt=System.currentTimeMillis();log("Access validated: "+result.endpoint);open("home");}
                else {unlocked=false;showActivation("License check failed: "+result.reason);}});
        }).start();
    }
    private void home(){startScreen("Welcome to WRP APP","Your private control center");
        LinearLayout p=panel();line(p,"✈  WRP APP","Dark Blue workspace · Admin-controlled access");
        LinearLayout stats=panel();line(stats,"ACCOUNTS     "+readArray("accounts").length()+"           SESSIONS     "+prefs.getInt("sessions",0),null);
        stats.addView(txt("Manual setup only · No unattended account creation",12,false,muted));
        p=panel();action(p,"Start Account Setup  →",()->open("create"));secondary(p,"Manage Accounts",()->open("accounts"));secondary(p,"Gmail Profiles",()->open("gmail"));
        p=panel();line(p,"TOOLS","Bring your own data and review each action");secondary(p,"Import Phone Numbers",()->pick(IMPORT_NUMBERS,"text/*"));secondary(p,"Backup & Restore",()->open("backup"));secondary(p,"Logs & History",()->open("logs"));
        bottom();
    }
    private void create(){startScreen("Create Account","Guided preparation · Verification always manual");
        LinearLayout p=panel();line(p,"1   Phone Number","Enter your own phone number (country code included).");
        EditText number=input(p,"+959XXXXXXXXX",prefs.getString("phone",""),false);
        line(p,"2   Country & Region","Select the country inside the official Telegram app.");
        line(p,"3   Name Settings","Use your chosen display name.");EditText name=input(p,"Your display name",prefs.getString("displayname",""),false);
        line(p,"4   Continue in Telegram","Official app handles terms, security checks and codes.");
        action(p,"Save & Open Telegram  →",()->{
            String n=number.getText().toString().trim(),label=name.getText().toString().trim();
            if(!n.matches("\\+?[0-9]{6,15}")){toast("Enter a valid phone number.");return;}
            prefs.edit().putString("phone",n).putString("displayname",label).putInt("sessions",prefs.getInt("sessions",0)+1).apply();
            log("Started a guided setup session");launchTelegram();
        });secondary(p,"Back to Home",()->open("home"));bottom();
    }
    private void launchTelegram(){try{Intent i=getPackageManager().getLaunchIntentForPackage("org.telegram.messenger");if(i==null){i=getPackageManager().getLaunchIntentForPackage("org.thunderdog.challegram");}if(i!=null)startActivity(i);else new AlertDialog.Builder(this).setMessage("Please install the official Telegram app to complete registration.").setPositiveButton("OK",null).show();}catch(ActivityNotFoundException e){toast("Telegram app not found.");}}
    private JSONArray readArray(String key){try{return new JSONArray(prefs.getString(key,"[]"));}catch(Exception e){return new JSONArray();}}
    private void saveArray(String key,JSONArray a){prefs.edit().putString(key,a.toString()).apply();}
    private void addEntry(String key,String label,int max){LinearLayout p=panel();EditText name=input(p,label,"",false);action(p,"Add",()->{String v=name.getText().toString().trim();if(v.isEmpty()||v.length()>100){toast("Enter 1–100 characters.");return;}JSONArray a=readArray(key);if(a.length()>=max){toast("Limit reached.");return;}a.put(v);saveArray(key,a);log("Added a local "+key+" entry");open(key.equals("gmail")?"gmail":"accounts");});}
    private void entries(LinearLayout p,String key){JSONArray a=readArray(key);for(int i=0;i<a.length();i++){final int index=i;String val=a.optString(i);LinearLayout item=new LinearLayout(this);item.setOrientation(LinearLayout.HORIZONTAL);item.setGravity(Gravity.CENTER_VERTICAL);p.addView(item);TextView textview=txt(val,13,false,text);item.addView(textview,new LinearLayout.LayoutParams(0,-2,1));TextView del=txt("Remove",12,true,accent());item.addView(del);del.setOnClickListener(v->new AlertDialog.Builder(this).setMessage("Remove this saved entry?").setNegativeButton("Cancel",null).setPositiveButton("Remove",(d,w)->{JSONArray newer=new JSONArray();for(int j=0;j<a.length();j++)if(j!=index)newer.put(a.opt(j));saveArray(key,newer);open(key.equals("gmail")?"gmail":"accounts");}).show());}}
    private void accounts(){startScreen("Manage Accounts","Local labels and phone list · No Telegram passwords stored");LinearLayout p=panel();line(p,"ACCOUNT LABELS  ·  "+readArray("accounts").length(),null);entries(p,"accounts");secondary(p,"Add Account Label",()->addEntry("accounts","Name / note",50));
        p=panel();line(p,"IMPORTED PHONE NUMBERS","These are saved locally, not registered automatically.");JSONArray phones=readArray("phone_list");p.addView(txt(phones.length()+" number(s) imported",14,true,accent()));secondary(p,"Import .txt / .csv",()->pick(IMPORT_NUMBERS,"text/*"));secondary(p,"Clear Imported Numbers",()->new AlertDialog.Builder(this).setMessage("Clear the imported phone list?").setNegativeButton("Cancel",null).setPositiveButton("Clear",(d,w)->{saveArray("phone_list",new JSONArray());open("accounts");}).show());bottom();}
    private void gmail(){startScreen("Gmail Manager","Local Gmail profiles · no inbox access without Google authorization");LinearLayout p=panel();line(p,"Saved Gmail Addresses  ·  "+readArray("gmail").length(),null);entries(p,"gmail");secondary(p,"Add Gmail Address",()->addEntry("gmail","you@gmail.com",15));p=panel();line(p,"Privacy","Automatic inbox reading and OTP extraction are not implemented. Never enter Gmail passwords here.");secondary(p,"Back",()->open("home"));bottom();}
    private void tools(){startScreen("WRP Tools","All settings in one place");LinearLayout p=panel();action(p,"Account Setup",()->open("create"));secondary(p,"Import Phone Numbers",()->pick(IMPORT_NUMBERS,"text/*"));secondary(p,"Gmail Manager",()->open("gmail"));secondary(p,"Backup & Restore",()->open("backup"));secondary(p,"Logs & History",()->open("logs"));p=panel();line(p,"Device Support","Shizuku / Termux are not connected in this build; Android security checks remain manual.");bottom();}
    private void settings(){startScreen("Settings","General, license and device preferences");LinearLayout p=panel();line(p,"GENERAL SETTINGS","Appearance");secondary(p,"Theme: "+prefs.getString("theme","darkblue"),()->new AlertDialog.Builder(this).setTitle("Choose WRP theme").setItems(new String[]{"Dark Blue","Dark Gold","Light"},(d,i)->{prefs.edit().putString("theme",new String[]{"darkblue","gold","light"}[i]).apply();open("settings");}).show());
        p=panel();line(p,"AUTOMATION SETTINGS","Security verification, permissions and terms require manual user actions. Automation toggles are intentionally not represented as working.");secondary(p,"Open Telegram",this::launchTelegram);
        p=panel();line(p,"LICENSE CONTROL","Access is verified using your primary server; standby can validate previously bound devices.");secondary(p,"Recheck License",()->checkLicense(false));secondary(p,"Change Server / Activation Key",()->showActivation("Enter your new server and key."));
        p=panel();secondary(p,"Backup & Restore",()->open("backup"));bottom();}
    private void log(String message){JSONArray a=readArray("logs"),b=new JSONArray();String date=new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(new Date());b.put(date+"  "+message);for(int i=0;i<a.length()&&i<49;i++)b.put(a.optString(i));saveArray("logs",b);}
    private void logs(){startScreen("Logs & History","Local WRP activity");LinearLayout p=panel();JSONArray a=readArray("logs");if(a.length()==0)line(p,"No entries yet",null);for(int i=0;i<a.length();i++)p.addView(txt(a.optString(i),12,false,muted));secondary(p,"Clear Logs",()->new AlertDialog.Builder(this).setMessage("Clear local logs?").setPositiveButton("Clear",(d,w)->{saveArray("logs",new JSONArray());open("logs");}).setNegativeButton("Cancel",null).show());bottom();}
    private void backup(){startScreen("Backup & Restore","Export local preferences only; server SQLite replication is configured separately.");LinearLayout p=panel();line(p,"LOCAL BACKUP","Exports account labels, Gmail address labels, phone list, theme and logs. Never exports admin key or device ID.");action(p,"Export Local Backup",()->{Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,"wrp-local-backup.json");startActivityForResult(i,EXPORT_BACKUP);});secondary(p,"Import Local Backup",()->pick(IMPORT_BACKUP,"application/json"));p=panel();line(p,"SERVER BACKUP","The included FastAPI backend supports SQLite snapshots and a standby replica. Deploy with HTTPS; do not put server passwords inside APK.");bottom();}
    private void pick(int request,String type){Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType(type);startActivityForResult(intent,request);}
    private JSONObject backupData()throws Exception{JSONObject j=new JSONObject();j.put("schema",1);for(String k:new String[]{"accounts","gmail","phone_list","logs"})j.put(k,readArray(k));j.put("theme",prefs.getString("theme","darkblue"));j.put("phone",prefs.getString("phone",""));j.put("displayname",prefs.getString("displayname",""));return j;}
    private byte[] readDoc(Uri uri)throws Exception{try(InputStream in=getContentResolver().openInputStream(uri);ByteArrayOutputStream out=new ByteArrayOutputStream()){if(in==null)throw new Exception("Cannot open file");byte[] buf=new byte[2048];int n;while((n=in.read(buf))!=-1){out.write(buf,0,n);if(out.size()>262144)throw new Exception("File too large");}return out.toByteArray();}}
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(result!=RESULT_OK||data==null||data.getData()==null)return;Uri uri=data.getData();try{
        if(request==EXPORT_BACKUP){try(OutputStream o=getContentResolver().openOutputStream(uri)){if(o==null)throw new Exception("Cannot write");o.write(backupData().toString(2).getBytes(StandardCharsets.UTF_8));}log("Exported local backup");toast("Backup exported.");}
        else if(request==IMPORT_BACKUP){JSONObject j=new JSONObject(new String(readDoc(uri),StandardCharsets.UTF_8));if(j.optInt("schema")!=1)throw new Exception("Unsupported format");for(String k:new String[]{"accounts","gmail","phone_list","logs"}){JSONArray a=j.optJSONArray(k);if(a==null||a.length()>200)throw new Exception("Invalid "+k);}for(String k:new String[]{"accounts","gmail","phone_list","logs"})saveArray(k,j.getJSONArray(k));String t=j.optString("theme","darkblue");prefs.edit().putString("theme",t.equals("light")||t.equals("gold")?t:"darkblue").putString("phone",j.optString("phone","")).putString("displayname",j.optString("displayname","")).apply();log("Restored local backup");toast("Backup restored.");open("backup");}
        else if(request==IMPORT_NUMBERS){String s=new String(readDoc(uri),StandardCharsets.UTF_8);JSONArray currentList=readArray("phone_list");for(String line:s.split("[,;\\r\\n]+")){String cleaned=line.trim().replace(" ","");if(cleaned.matches("\\+?[0-9]{6,15}")&&currentList.length()<200)currentList.put(cleaned);}saveArray("phone_list",currentList);log("Imported phone number list");toast("Imported "+currentList.length()+" phone numbers.");open("accounts");}
    }catch(Exception ex){toast("File error: "+ex.getMessage());}}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
