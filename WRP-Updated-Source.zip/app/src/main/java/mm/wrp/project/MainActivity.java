package mm.wrp.project;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.util.Patterns;
import android.widget.Toast;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.content.res.ColorStateList;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.WindowInsets;
import android.widget.ProgressBar;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.text.InputType;
import android.util.TypedValue;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final int BLUE = Color.rgb(229, 193, 122);
    private static final int NAVY = Color.rgb(244, 245, 247);
    private static final int GREY = Color.rgb(173, 184, 202);
    private static final int BG = Color.rgb(16, 21, 29);
    private static final String PREF_NAME = "wrp_v03_prefs";
    private static final String SERVER_KEY = "server_url";
    private static final String ACCOUNTS_KEY = "account_labels";
    private static final String PHONE_PREF = "preset_phone";
    private static final String GMAIL_PREF = "gmail_addresses";
    private static final String GMAIL_CURSOR_PREF = "gmail_rotation_cursor";

    private SharedPreferences prefs;
    private SecureStore secrets;
    private LinearLayout root;
    private volatile boolean verifying = false;
    private boolean unlocked = false;
    private boolean resumed = false;
    private long lastVerifiedMs = 0;
    private String expiryText = "";
    private String deviceId;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable licenseRefresh = () -> {
        if (unlocked && !verifying) {
            unlocked = false;
            showLoading("Refreshing your secure session…");
            verify(prefs.getString(SERVER_KEY, ""), secrets.get(), false);
        }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences(PREF_NAME, MODE_PRIVATE);
        secrets = new SecureStore(this);
        deviceId = prefs.getString("device_id", null);
        if (deviceId == null) {
            deviceId = UUID.randomUUID().toString();
            prefs.edit().putString("device_id", deviceId).apply();
        }
        setupRoot();
        String server = prefs.getString(SERVER_KEY, "");
        String key = secrets.get();
        if (!server.isEmpty() && key != null) {
            showLoading("Checking saved activation with server...");
            verify(server, key, false);
        } else showActivation("Activate WRP to enter your dashboard.");
    }

    @Override protected void onResume() {
        super.onResume();
        resumed = true;
        if (unlocked && !verifying && SystemClock.elapsedRealtime() - lastVerifiedMs > 30000) {
            String url = prefs.getString(SERVER_KEY, "");
            String key = secrets.get();
            unlocked = false;
            showLoading("Rechecking license...");
            if (key != null && !url.isEmpty()) verify(url, key, false);
            else showActivation("No valid saved activation.");
        }
        if (unlocked) scheduleRefresh();
    }

    @Override protected void onPause() {
        resumed = false;
        handler.removeCallbacks(licenseRefresh);
        super.onPause();
    }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    private void scheduleRefresh() {
        handler.removeCallbacks(licenseRefresh);
        handler.postDelayed(licenseRefresh,
                Math.max(1, 30000 - (SystemClock.elapsedRealtime() - lastVerifiedMs)));
    }

    private int dp(int n) {
        return Math.round(getResources().getDisplayMetrics().density * n);
    }

    private void setupRoot() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(24), dp(30), dp(24), dp(26));
        scroll.setOnApplyWindowInsetsListener((view, insets) -> {
            if (android.os.Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(
                        WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                view.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            } else {
                view.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(),
                        insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
            }
            return insets;
        });
        scroll.addView(root);
        setContentView(scroll);
        scroll.requestApplyInsets();
    }

    private GradientDrawable bg(int color, int radius) {
        GradientDrawable b = new GradientDrawable();
        b.setColor(color);
        b.setCornerRadius(dp(radius));
        return b;
    }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(color);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, size);
        t.setTypeface(Typeface.create(bold ? "sans-serif-medium" : "sans-serif", Typeface.NORMAL));
        t.setLineSpacing(dp(3), 1f);
        t.setPadding(0, dp(5), 0, dp(5));
        return t;
    }

    private void header(String subtitle) {
        root.removeAllViews();
        TextView edition = text("WRP  /  PRIVATE WORKSPACE", 11, BLUE, true);
        edition.setLetterSpacing(0.16f);
        root.addView(edition);
        gap(16);
        root.addView(text(subtitle, 30, NAVY, true));
        root.addView(text("Your registration companion. Thoughtfully organized.", 14, GREY, false));
        gap(22);
    }

    private void gap(int h) {
        View spacer = new View(this);
        root.addView(spacer, new LinearLayout.LayoutParams(1, dp(h)));
    }

    private LinearLayout card() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(16), dp(18), dp(18));
        GradientDrawable surface = bg(Color.rgb(25, 33, 45), 22);
        surface.setStroke(dp(1), Color.rgb(48, 60, 77));
        box.setBackground(surface);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.bottomMargin = dp(14);
        root.addView(box, params);
        return box;
    }

    private Button button(String label, LinearLayout container, Runnable click) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(label);
        b.setTextSize(14);
        b.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        b.setTextColor(BG);
        b.setPadding(dp(16), dp(12), dp(16), dp(12));
        b.setMinHeight(dp(52));
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x33505050), bg(BLUE, 14), null));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(12);
        container.addView(b, p);
        b.setOnClickListener(v -> { if (!verifying) click.run(); });
        return b;
    }

    private EditText field(LinearLayout container, String hint, boolean password) {
        EditText e = new EditText(this);
        e.setSingleLine(true);
        e.setTextSize(15);
        e.setHint(hint);
        e.setContentDescription(hint);
        e.setTextColor(NAVY);
        e.setHintTextColor(GREY);
        e.setPadding(dp(14), dp(12), dp(14), dp(12));
        GradientDrawable input = bg(BG, 12);
        input.setStroke(dp(1), Color.rgb(67, 81, 101));
        e.setBackground(input);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        if (password) {
            e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                e.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO);
            }
            e.setSaveEnabled(false);
        }
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, dp(56));
        params.topMargin = dp(6);
        params.bottomMargin = dp(14);
        container.addView(e, params);
        return e;
    }

    private void showLoading(String message) {
        header("A secure start.");
        LinearLayout panel = card();
        ProgressBar progress = new ProgressBar(this);
        progress.setIndeterminateTintList(ColorStateList.valueOf(BLUE));
        panel.addView(progress, new LinearLayout.LayoutParams(dp(36), dp(36)));
        panel.addView(text(message, 16, GREY, false));
        panel.addView(text("An active server connection is required. Free hosting may take a minute to wake.", 13, GREY, false));
    }

    private void showActivation(String message) {
        unlocked = false;
        handler.removeCallbacks(licenseRefresh);
        header("Make it yours.");
        LinearLayout welcome = card();
        welcome.addView(text("ONE KEY. YOUR WORKSPACE.", 11, BLUE, true));
        welcome.addView(text("Designed for a calmer workflow", 22, NAVY, true));
        welcome.addView(text("Connect to your administrator’s server to unlock your private WRP dashboard.", 14, GREY, false));
        LinearLayout panel = card();
        panel.addView(text("HTTPS Server URL", 14, NAVY, true));
        EditText server = field(panel, "https://your-server.onrender.com", false);
        server.setText(prefs.getString(SERVER_KEY, ""));
        panel.addView(text("Activation Key", 14, NAVY, true));
        EditText key = field(panel, "wrp_...", true);
        TextView info = text(message, 13, GREY, false);
        info.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        panel.addView(info);
        Button activate = button("Activate / Verify", panel, () -> {
            String url;
            try { url = ActivationClient.normalizeServer(server.getText().toString()); }
            catch (Exception error) {
                info.setText(R.string.invalid_server);
                return;
            }
            String k = key.getText().toString().trim();
            if (!k.matches("wrp_[a-zA-Z0-9_-]{24,}")) {
                info.setText(R.string.invalid_activation_key);
                return;
            }
            showLoading("Verifying your activation…");
            verify(url, k, true);
        });
        activate.setTag("activate_button");
        String stored = secrets.get();
        if (stored != null && !prefs.getString(SERVER_KEY, "").isEmpty()) {
            button("Recheck saved activation", panel, () -> {
                if (verifying) return;
                showLoading("Rechecking saved activation...");
                verify(prefs.getString(SERVER_KEY, ""), secrets.get(), false);
            });
            button("Clear saved activation", panel, () -> new AlertDialog.Builder(this)
                    .setTitle("Clear saved license?")
                    .setMessage("This clears this app's local key but does not release the server-side device binding.")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Clear", (d, w) -> {
                        secrets.clear();
                        prefs.edit().remove(SERVER_KEY).apply();
                        showActivation("Saved activation cleared.");
                    }).show());
        }
        LinearLayout note = card();
        note.addView(text("WRP stores your phone and Gmail selection settings locally. Telegram verification remains user-controlled.", 13, GREY, false));
    }

    private void verify(String base, String key, boolean saveKey) {
        if (verifying) return;
        if (key == null) {
            showActivation("No saved activation. Enter your key to continue.");
            return;
        }
        verifying = true;
        new Thread(() -> {
            boolean ok = false;
            String expiry = "";
            try {
                JSONObject result = new ActivationClient().activate(base, key, deviceId);
                expiry = result.getString("expiresAt");
                if (saveKey) {
                    secrets.put(key);
                    prefs.edit().putString(SERVER_KEY, ActivationClient.normalizeServer(base)).apply();
                }
                ok = true;
            } catch (Exception error) {
                // Keep credentials and server response bodies out of logs.
            }
            final boolean verified = ok;
            final String resultExpiry = expiry;
            runOnUiThread(() -> {
                if (isDestroyed() || isFinishing()) return;
                verifying = false;
                if (verified) {
                    unlocked = true;
                    lastVerifiedMs = SystemClock.elapsedRealtime();
                    expiryText = resultExpiry;
                    showDashboard();
                    if (resumed) scheduleRefresh();
                } else {
                    showActivation("Unable to verify. Check your connection, server address and key. Your administrator can check expiry or revocation.");
                }
            });
        }, "wrp-activation").start();
    }

    private void showDashboard() {
        if (!unlocked) return;
        header("Your workspace.");
        LinearLayout license = card();
        license.addView(text("●  MEMBERSHIP ACTIVE", 20, Color.rgb(128, 217, 180), true));
        license.addView(text("Expiry: " + (expiryText.isEmpty() ? "See admin panel" : expiryText), 13, GREY, false));
        license.addView(text("License checked online for this installation.", 12, GREY, false));
        button("Refresh License", license, () -> {
            unlocked = false;
            showLoading("Refreshing license...");
            verify(prefs.getString(SERVER_KEY, ""), secrets.get(), false);
        });

        LinearLayout tools = card();
        tools.addView(text("Ready when you are", 20, NAVY, true));
        button("Open Telegram", tools, this::openTelegram);
        button("Registration Settings (Phone + Gmail)", tools, this::showRegistrationSettings);
        button("Prepare Registration Session", tools, this::prepareRegistration);
        button("Account Labels (local notes)", tools, this::showAccounts);
        tools.addView(text("Gmail auto-selection is local to WRP. This app does not sign into Gmail, read OTPs, or submit Telegram verification automatically.", 12, GREY, false));

        LinearLayout controls = card();
        controls.addView(text("Your session", 20, NAVY, true));
        button("Lock Dashboard", controls, () -> showActivation("Session locked. Recheck saved activation to unlock."));
        button("Forget Activation Key", controls, () -> new AlertDialog.Builder(this)
                .setTitle("Forget this activation?")
                .setMessage("The server still ties this license to this installation. Forgetting does not revoke that binding.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Forget", (d, w) -> {
                    secrets.clear();
                    unlocked = false;
                    showActivation("Key cleared locally. Generate a new key if needed.");
                }).show());
        controls.addView(text("No background automation, OTP handling, or bulk account creation runs in this version.", 12, GREY, false));
    }

    private void openTelegram() {
        String[] packages = { "org.telegram.messenger", "org.thunderdog.challegram" };
        for (String p : packages) {
            Intent intent = getPackageManager().getLaunchIntentForPackage(p);
            if (intent != null) {
                startActivity(intent);
                return;
            }
        }
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://telegram.org/android")));
        } catch (ActivityNotFoundException ex) {
            new AlertDialog.Builder(this).setMessage("Install the official Telegram application to continue.")
                    .setPositiveButton("OK", null).show();
        }
    }

    private JSONArray gmailAddresses() {
        try { return new JSONArray(prefs.getString(GMAIL_PREF, "[]")); }
        catch (Exception e) { return new JSONArray(); }
    }

    private void showRegistrationSettings() {
        if (!unlocked) { showActivation("License verification required."); return; }
        header("Registration Settings");
        LinearLayout panel = card();
        panel.addView(text("Phone number for your own Telegram sign-up", 16, NAVY, true));
        EditText number = field(panel, "+959XXXXXXXXX", false);
        number.setInputType(InputType.TYPE_CLASS_PHONE);
        number.setText(prefs.getString(PHONE_PREF, ""));
        button("Save Phone Number", panel, () -> {
            String phone = number.getText().toString().trim().replaceAll("[\\s()-]", "");
            if (!phone.matches("\\+?[0-9]{6,15}")) {
                new AlertDialog.Builder(this).setMessage("Use 6-15 digits, optionally starting with +. Provide a number you control.")
                    .setPositiveButton("OK", null).show();
                return;
            }
            prefs.edit().putString(PHONE_PREF, phone).apply();
            Toast.makeText(this, "Phone saved locally", Toast.LENGTH_SHORT).show();
        });

        LinearLayout emails = card();
        JSONArray data = gmailAddresses();
        emails.addView(text("Gmail profiles: " + data.length(), 18, NAVY, true));
        for (int i = 0; i < data.length(); i++) {
            emails.addView(text((i + 1) + ". " + data.optString(i), 14, GREY, false));
        }
        button("Add Gmail Address", emails, this::addGmail);
        button("Remove Gmail Address", emails, this::removeGmail);
        emails.addView(text("Only email addresses are saved on this device. No Gmail permissions, passwords, OTPs or API tokens are requested.", 12, GREY, false));

        LinearLayout actions = card();
        actions.addView(text("Selection Mode: Rotation", 17, NAVY, true));
        actions.addView(text("Prepare Session selects the next saved Gmail label in order, then displays it for your confirmation. It cannot choose a Gmail account inside Telegram or access your Gmail messages.", 13, GREY, false));
        button("Prepare Session", actions, this::prepareRegistration);
        button("Back to Dashboard", actions, this::showDashboard);
    }

    private void addGmail() {
        JSONArray data = gmailAddresses();
        if (data.length() >= 15) {
            new AlertDialog.Builder(this).setMessage("Maximum 15 saved addresses.")
                .setPositiveButton("OK", null).show();
            return;
        }
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        input.setHint("yourname@gmail.com");
        new AlertDialog.Builder(this)
            .setTitle("Add a Gmail address you control")
            .setView(input)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Add", (dialog, which) -> {
                String email = input.getText().toString().trim().toLowerCase(java.util.Locale.ROOT);
                if (!Patterns.EMAIL_ADDRESS.matcher(email).matches() ||
                    !(email.endsWith("@gmail.com") || email.endsWith("@googlemail.com"))) {
                    Toast.makeText(this, "Enter a valid Gmail address", Toast.LENGTH_LONG).show();
                    showRegistrationSettings();
                    return;
                }
                for (int j = 0; j < data.length(); j++) {
                    if (email.equalsIgnoreCase(data.optString(j))) {
                        Toast.makeText(this, "Already saved", Toast.LENGTH_SHORT).show();
                        showRegistrationSettings();
                        return;
                    }
                }
                data.put(email);
                prefs.edit().putString(GMAIL_PREF, data.toString()).apply();
                showRegistrationSettings();
            }).show();
    }

    private void removeGmail() {
        JSONArray data = gmailAddresses();
        if (data.length() == 0) {
            Toast.makeText(this, "No saved Gmail addresses", Toast.LENGTH_SHORT).show();
            return;
        }
        String[] addresses = new String[data.length()];
        for (int i=0; i<data.length(); i++) addresses[i] = data.optString(i);
        new AlertDialog.Builder(this)
            .setTitle("Remove a saved address")
            .setItems(addresses, (dialog, index) -> {
                JSONArray remaining = new JSONArray();
                for (int j = 0; j < data.length(); j++) {
                    if (j != index) remaining.put(data.optString(j));
                }
                prefs.edit()
                    .putString(GMAIL_PREF, remaining.toString())
                    .putInt(GMAIL_CURSOR_PREF, 0)
                    .apply();
                showRegistrationSettings();
            })
            .setNegativeButton("Cancel", null).show();
    }

    private void prepareRegistration() {
        if (!unlocked) { showActivation("License verification required."); return; }
        String phone = prefs.getString(PHONE_PREF, "");
        JSONArray data = gmailAddresses();
        if (!phone.matches("\\+?[0-9]{6,15}") || data.length() == 0) {
            new AlertDialog.Builder(this)
                .setTitle("Set up your registration preferences")
                .setMessage("Save a phone number and at least one Gmail address first.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Open Settings", (d,w) -> showRegistrationSettings())
                .show();
            return;
        }
        int cursor = prefs.getInt(GMAIL_CURSOR_PREF, 0);
        int index = Math.floorMod(cursor, data.length());
        String selected = data.optString(index);
        prefs.edit().putInt(GMAIL_CURSOR_PREF, (index + 1) % data.length()).apply();
        header("Registration Session Prepared");
        LinearLayout panel = card();
        panel.addView(text("Phone: " + phone, 16, NAVY, true));
        panel.addView(text("Selected Gmail: " + selected, 16, NAVY, true));
        panel.addView(text("Gmail selection is local to WRP only. Sign-up and all Telegram verification must be completed in Telegram by you.", 13, GREY, false));
        button("Copy Phone Number", panel, () -> {
            ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (clipboard != null) {
                clipboard.setPrimaryClip(ClipData.newPlainText("phone", phone));
                Toast.makeText(this, "Phone copied", Toast.LENGTH_SHORT).show();
            }
        });
        button("Open Telegram", panel, this::openTelegram);
        button("Choose Next Gmail Profile", panel, this::prepareRegistration);
        button("Back to Dashboard", panel, this::showDashboard);
    }

    private JSONArray accountLabels() {
        try { return new JSONArray(prefs.getString(ACCOUNTS_KEY, "[]")); }
        catch (Exception e) { return new JSONArray(); }
    }

    private void showAccounts() {
        if (!unlocked) { showActivation("License verification required."); return; }
        JSONArray current = accountLabels();
        String[] labels = new String[current.length()];
        for (int i = 0; i < current.length(); i++) labels[i] = current.optString(i, "");
        AlertDialog.Builder dialog = new AlertDialog.Builder(this)
                .setTitle("Account Labels — notes only")
                .setMessage("Do not enter Telegram passwords, OTPs or recovery codes here.")
                .setPositiveButton("Add Label", (d, n) -> addLabel())
                .setNegativeButton("Close", null);
        if (labels.length > 0) {
            dialog.setItems(labels, (d, i) -> new AlertDialog.Builder(this)
                    .setTitle("Delete label?")
                    .setMessage(labels[i])
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Delete", (dd, nn) -> {
                        JSONArray next = new JSONArray();
                        for (int j = 0; j < current.length(); j++) if (j != i) next.put(current.optString(j, ""));
                        prefs.edit().putString(ACCOUNTS_KEY, next.toString()).apply();
                        showAccounts();
                    }).show());
        }
        dialog.show();
    }

    private void addLabel() {
        JSONArray labels = accountLabels();
        if (labels.length() >= 10) {
            new AlertDialog.Builder(this).setMessage("Maximum 10 local labels.")
                    .setPositiveButton("OK", null).show();
            return;
        }
        EditText entry = new EditText(this);
        entry.setSingleLine(true);
        entry.setHint("Example: Personal account");
        new AlertDialog.Builder(this)
                .setTitle("Add local label")
                .setView(entry)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save", (d, n) -> {
                    String value = entry.getText().toString().trim();
                    if (!value.isEmpty() && value.length() <= 50) {
                        labels.put(value);
                        prefs.edit().putString(ACCOUNTS_KEY, labels.toString()).apply();
                    }
                    showAccounts();
                }).show();
    }
}
