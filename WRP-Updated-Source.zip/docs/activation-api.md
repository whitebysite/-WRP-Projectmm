# Activation API

All responses use JSON and `Cache-Control: no-store`. Host behind HTTPS in
production. Keys, bearer tokens and installation IDs must not be logged by a
reverse proxy or analytics service. The Android client calls only `/api/activate`.

| Method / path | Authorization | Body | Success |
| --- | --- | --- | --- |
| `GET /health` | None | — | `200 { ok: true, service }` |
| `GET /admin` | None to load page | — | HTML; data requests require admin token |
| `POST /api/admin/keys` | `Bearer ADMIN_TOKEN` | `{ "days": 30 }`, integer 1–365 | `201 { ok, key, id, expiresAt }` |
| `GET /api/admin/keys` | `Bearer ADMIN_TOKEN` | — | `200 { ok, keys: [{ id, createdAt, expiresAt, revoked, bound }] }` |
| `POST /api/admin/keys/revoke` | `Bearer ADMIN_TOKEN` | `{ "id": "<key-id>" }` | `200 { ok, id, revoked: true }` |
| `POST /api/activate` | Issued activation key in body | `{ "key": "<issued-key>", "deviceId": "<installation-uuid>" }` | `200 { ok: true, expiresAt }` |

Errors use `{ "ok": false, "error": "..." }`: invalid requests return `400`,
missing/incorrect admin authorization `401`, unusable or differently bound keys
`403`, unknown routes/IDs `404`, and excessive requests `429`.

The activation key is returned once at issuance. Admin listings and disk storage
never contain the original key. Keys bind to a random installation UUID, not a
hardware identifier. Repeating activation on that installation is allowed until
expiry or revocation. A key cannot be moved to a second installation; issue a
replacement and revoke the old key. Expiry begins at issuance.

The body size limit is 8 KiB. The server permits 60 API requests per minute per
socket IP. It intentionally does not trust arbitrary `X-Forwarded-For` headers.
Behind a proxy this can combine clients into one bucket: configure rate limiting
at the trusted ingress before production traffic and design trusted-proxy IP
handling before changing this policy.

Use one server process with a persistent volume. Writes use a temporary file and
atomic rename, but do not provide multi-process transactions. Storage errors
require operator attention. Keep store backups and the pepper together under
access control. Rotating the pepper invalidates existing key/device hashes.

An APK can be modified by its recipient. The dashboard check controls this
client's UI; any future valuable backend operation must independently enforce
server authorization. No server-hosted premium operation is provided here.

## GitHub publishing permissions

Repository ownership and an integration's granted permissions are separate.
To publish this change, the connected GitHub App needs access to this repository
with **Contents: Read and write**, **Workflows: Read and write**, and **Pull
requests: Read and write**. Reading collaborator permissions additionally needs
**Administration: Read**, which is optional for development and publishing.
Keep branch protection and other repository security controls enabled.
