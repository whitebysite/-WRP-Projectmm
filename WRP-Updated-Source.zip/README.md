# WRP APP v1.0 Beta — Android workspace + own primary/standby admin backend

This is a **new native Android UI built from auditable source** using the supplied Relay design/requirements as reference. It does **not** transplant or claim to restore the compiled Relay APK implementation. Original Relay DEX classes and their automation workflows are NOT included. Use the preserved `Relay-Recovered-Project.zip` for separate recovery and functional parity work.

## Included Android functionality

- WRP-themed charcoal/navy/electric blue dashboard, dark gold and light theme options
- Device-bound license activation (HTTPS primary and backup /v1/license/check), encrypted activation key storage via Android Keystore
- Guided Telegram launch and manually controlled account setup
- Local account labels, Gmail address labels (no inbox access), phone-number text/CSV import and validation
- Local JSON backup/export/restore with Android Storage Access Framework (license key excluded)
- Local activity logs, settings and primary/standby endpoint configuration
- No claim of fully automated Telegram registration, UI automation, Shizuku/Termux shell use, OTP extraction or proxy routing; these are NOT implemented.

## Build

JDK 17, Android SDK 35, build-tools 35.0.0, Gradle 8.9. Run:

    gradle --no-daemon :app:assembleDebug

Output: `app/build/outputs/apk/debug/app-debug.apk`.

**GitHub:** replace the repository's `WRP-Updated-Source.zip` with `WRP-v1-Source.zip` renamed to `WRP-Updated-Source.zip` (or change the existing workflow to point to the new filename), then commit. Existing `build-apk.yml` extracts source and builds `app:assembleDebug`.

## Backend

See `wrp-backend/DEPLOYMENT-GUIDE.md` for production deployment. Configure HTTPS domain and strong server-side environment secrets, create user activation keys at the admin web dashboard. App accepts **primary and backup HTTPS origins**, and refuses access when unvalidated. Deploying locally in a container is **not** deploying a publicly usable backup server. The app does not and should not contain admin or backup tokens.

## Installation note

Package ID: `mm.wrp.project.v1`. New debug signing key means it may not upgrade previously installed WRP 0.4/Relay. Back up data and use a test device. The UI remains a separate WRP app, not a patched copy of Relay.
