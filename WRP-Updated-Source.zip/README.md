# WRP Android

WRP is a native Android registration companion with a private dashboard and an
administrator-operated activation server. Phone preferences, Gmail address labels
and account notes stay on the device. Telegram registration remains user-controlled.

The Android source is committed under `app/`; GitHub Actions builds that source
directly. The application ID remains `mm.wrp.project.v03` so existing installations
can upgrade when signed with the same signing key. Version: **0.4.0-beta**.

## Project layout

```text
app/src/main/java/mm/wrp/project/
  MainActivity.java       Native charcoal/gold UI and local preferences
  ActivationClient.java  HTTPS-only, device-bound activation client
  SecureStore.java       Android Keystore AES-GCM storage
app/src/main/res/values/  Application theme
server.js                Activation API and /admin console
test/                    Server lifecycle integration tests
.github/workflows/       Android build/lint and server checks
```

## Build Android

Use Android Studio, or install JDK 17, Gradle 8.9, Android SDK platform 35 and
build tools 35.0.0. Set `ANDROID_HOME` to the SDK directory, then run:

```sh
gradle --no-daemon :app:testDebugUnitTest :app:lintDebug :app:assembleDebug
```

The APK is written to `app/build/outputs/apk/debug/app-debug.apk`. There is no
Gradle wrapper checked in; the workflow provisions the pinned Gradle version.
Debug APKs are for testing. Release distribution requires your own signing setup;
keep signing keys and passwords outside the repository.

The workflow runs on pushes to `main` and `wrp-development`, pull requests to
`main`, and manual dispatch. It checks the backend, lints Android, builds and
validates the debug APK, and uploads APK and source ZIP artifacts for 14 days.
It uses `contents: read` and requires no server secrets.

## Run the activation server

Use Node.js 22 (20.6+ supported). No npm dependencies are required.

1. Copy `.env.example` to `.env`.
2. Generate **two different random values**, at least 32 characters each, using
   a password manager. Set `ADMIN_TOKEN` and `KEY_PEPPER` in `.env`.
3. Start locally with `node --env-file=.env server.js`.
4. Open `http://127.0.0.1:10000/admin` and enter the admin token.

For hosting, configure these variables in your host's secret settings, set
`HOST=0.0.0.0`, use `npm start`, expose HTTPS through your hosting platform, and
mount persistent storage at `STORE_FILE`. `/health` is the health check.
Never send the admin token or key pepper to Android clients.

In the console, generate an activation key and copy it immediately. Enter the
server's **HTTPS origin** and the issued key in Android. Validity begins at key
issuance. The first activation binds the key to that app installation; clearing
app data or reinstalling requires a newly issued key. Revoke a key in `/admin`
to deny subsequent verification. The console's Lock button clears displayed
credentials and keys from the page.

The dashboard checks activation at startup, after returning from a long pause,
and every 30 seconds while open. It locks during checks and stays locked when
the server cannot verify the license. Activation keys are encrypted locally
with Android Keystore; the server stores only HMACs of keys and installation IDs.
The app refuses HTTP, credentials in URLs, URL paths/queries, and redirects.

This is a development foundation. The file-backed server needs one process and
a durable volume; use a transactional database before scaling to multiple
instances. Back up the data file and preserve `KEY_PEPPER`, or existing keys
become unusable. Do not expose the admin console over plain HTTP outside local
development. See [the API contract](docs/activation-api.md) for operational limits.

## Validate

```sh
npm run check
npm test
```

Tests use temporary storage, random test credentials and a loopback server. They
cover admin authorization, request validation, device binding, restart
persistence, revocation, expiration, safe responses and rate limiting. Android
unit tests check HTTPS origin validation, including rejected credentials, paths,
queries, fragments, insecure schemes and invalid ports.
